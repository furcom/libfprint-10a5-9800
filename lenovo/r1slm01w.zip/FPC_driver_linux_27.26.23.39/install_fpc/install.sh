sudo cp ./libfpcbep.so /usr/lib/x86_64-linux-gnu/

